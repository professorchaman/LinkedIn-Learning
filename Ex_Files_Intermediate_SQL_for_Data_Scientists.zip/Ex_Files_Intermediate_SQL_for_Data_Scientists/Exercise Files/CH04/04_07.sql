﻿select
  *
from 
   data_sci.employees e
order by
  salary desc
limit 10
   
select
  *
from 
   data_sci.employees e
order by
  salary desc
fetch first 10 rows only