﻿select
    salary
from
    data_sci.employees




select
    avg(salary)
from
    data_sci.employees






select
   trunc( avg(salary))
from
    data_sci.employees




select
   trunc( avg(salary))
from
    data_sci.employees




select
   trunc( avg(salary),2)
from
    data_sci.employees


select
   ceil(avg(salary))
from
   data_sci.employees


select
   trunc( avg(salary),2)
from
    data_sci.employees




select
   trunc( avg(salary),4)
from
    data_sci.employees